import React from 'react';
import Login from './Login';
import Home from './Home'

function App() {
  return (
    <Login></Login>
  );
}

export default App;
