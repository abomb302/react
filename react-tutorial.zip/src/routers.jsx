import App from './App';
import Login from './Login';
import Home from './Home';
import { BrowserRouter, Link, Route } from 'react-router-dom';

const routes = (
    <BrowserRouter>
        <div>
            <Route path="/" component={Login} />
            <Route path="/home" component={Home} />
        </div>
    </BrowserRouter>
);

export default routes;